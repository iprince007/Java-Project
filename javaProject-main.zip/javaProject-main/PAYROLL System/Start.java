public class Start{
	public static void main(String[]args){
		Payroll p=new Payroll();
		p.setVisible(true);
	}
}